<?php
require_once 'includes/header.php';
require_once 'includes/functions.php';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get all destinations for the form
    $destinations = getDestinations($conn);
    
    // Process form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Validate input
        $destination_id = (int)$_POST['destination_id'];
        $title = sanitizeInput($_POST['title']);
        $description = sanitizeInput($_POST['description']);
        $duration = sanitizeInput($_POST['duration']);
        $price = (float)$_POST['price'];
        
        if (empty($title) || empty($description) || empty($duration) || $price <= 0 || $destination_id <= 0) {
            $error = "All fields are required and price must be greater than zero.";
        } else {
            // Handle image upload
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $uploadResult = uploadImage($_FILES['image']);
                
                if ($uploadResult['success']) {
                    $image = $uploadResult['file_name'];
                    
                    // Insert tour into database
                    $stmt = $conn->prepare("INSERT INTO tours (destination_id, title, description, image, duration, price) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$destination_id, $title, $description, $image, $duration, $price]);
                    
                    $success = "Tour added successfully!";
                    // Clear form data after successful submission
                    $formData = null;
                } else {
                    $error = $uploadResult['message'];
                }
            } else {
                $error = "Please select an image for the tour.";
            }
        }
    }
    
} catch(PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
?>

<div class="mb-4">
    <div class="d-flex justify-content-between align-items-center">
        <h5>Add New Tour</h5>
        <a href="tours.php" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Back to Tours
        </a>
    </div>
</div>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        Tour Information
    </div>
    <div class="card-body">
        <form method="post" action="" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="destination_id" class="form-label">Destination</label>
                        <select class="form-select" id="destination_id" name="destination_id" required>
                            <option value="">Select Destination</option>
                            <?php foreach ($destinations as $destination): ?>
                                <option value="<?php echo $destination['id']; ?>" <?php echo (isset($formData['destination_id']) && $formData['destination_id'] == $destination['id']) ? 'selected' : ''; ?>>
                                    <?php echo $destination['name']; ?> (<?php echo $destination['category_name']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="title" class="form-label">Tour Title</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo isset($formData['title']) ? $formData['title'] : ''; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="duration" class="form-label">Duration</label>
                        <input type="text" class="form-control" id="duration" name="duration" placeholder="e.g. 3 Days 2 Nights" value="<?php echo isset($formData['duration']) ? $formData['duration'] : ''; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="price" class="form-label">Price (₹)</label>
                        <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" value="<?php echo isset($formData['price']) ? $formData['price'] : ''; ?>" required>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="image" class="form-label">Tour Image</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                        <div class="form-text">Upload an image for the tour (JPG, PNG, GIF).</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="8" required><?php echo isset($formData['description']) ? $formData['description'] : ''; ?></textarea>
                    </div>
                </div>
            </div>
            
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> Add Tour
                </button>
                <a href="tours.php" class="btn btn-secondary ms-2">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>