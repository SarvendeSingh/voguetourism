<?php
require_once 'includes/header.php';
require_once 'includes/functions.php';

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: tours.php');
    exit;
}

$tour_id = (int)$_GET['id'];

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get tour details
    $tour = getTour($conn, $tour_id);
    
    if (!$tour) {
        header('Location: tours.php');
        exit;
    }
    
    // Get all destinations for the form
    $destinations = getDestinations($conn);
    
    // Process form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Validate input
        $destination_id = (int)$_POST['destination_id'];
        $title = sanitizeInput($_POST['title']);
        $description = sanitizeInput($_POST['description']);
        $duration = sanitizeInput($_POST['duration']);
        $price = (float)$_POST['price'];
        
        if (empty($title) || empty($description) || empty($duration) || $price <= 0 || $destination_id <= 0) {
            $error = "All fields are required and price must be greater than zero.";
        } else {
            $image = $tour['image']; // Keep existing image by default
            
            // Handle image upload if a new image is provided
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $uploadResult = uploadImage($_FILES['image']);
                
                if ($uploadResult['success']) {
                    // Delete old image if it exists
                    if ($tour['image'] && file_exists("../uploads/tours/" . $tour['image'])) {
                        unlink("../uploads/tours/" . $tour['image']);
                    }
                    
                    $image = $uploadResult['file_name'];
                } else {
                    $error = $uploadResult['message'];
                }
            }
            
            if (!isset($error)) {
                // Update tour in database
                $stmt = $conn->prepare("UPDATE tours SET destination_id = ?, title = ?, description = ?, image = ?, duration = ?, price = ? WHERE id = ?");
                $stmt->execute([$destination_id, $title, $description, $image, $duration, $price, $tour_id]);
                
                $success = "Tour updated successfully!";
                
                // Refresh tour data
                $tour = getTour($conn, $tour_id);
            }
        }
    }
    
} catch(PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
?>

<div class="mb-4">
    <div class="d-flex justify-content-between align-items-center">
        <h5>Edit Tour: <?php echo $tour['title']; ?></h5>
        <a href="tours.php" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Back to Tours
        </a>
    </div>
</div>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        Tour Information
    </div>
    <div class="card-body">
        <form method="post" action="" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="destination_id" class="form-label">Destination</label>
                        <select class="form-select" id="destination_id" name="destination_id" required>
                            <option value="">Select Destination</option>
                            <?php foreach ($destinations as $destination): ?>
                                <option value="<?php echo $destination['id']; ?>" <?php echo ($tour['destination_id'] == $destination['id']) ? 'selected' : ''; ?>>
                                    <?php echo $destination['name']; ?> (<?php echo $destination['category_name']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="title" class="form-label">Tour Title</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo $tour['title']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="duration" class="form-label">Duration</label>
                        <input type="text" class="form-control" id="duration" name="duration" placeholder="e.g. 3 Days 2 Nights" value="<?php echo $tour['duration']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="price" class="form-label">Price (₹)</label>
                        <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" value="<?php echo $tour['price']; ?>" required>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="image" class="form-label">Tour Image</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        <div class="form-text">Upload a new image to replace the current one (optional).</div>
                        
                        <?php if ($tour['image']): ?>
                            <div class="mt-2">
                                <p>Current Image:</p>
                                <img src="../uploads/tours/<?php echo $tour['image']; ?>" alt="<?php echo $tour['title']; ?>" class="img-thumbnail" style="max-width: 200px;">
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="8" required><?php echo $tour['description']; ?></textarea>
                    </div>
                </div>
            </div>
            
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save"></i> Update Tour
                </button>
                <a href="tours.php" class="btn btn-secondary ms-2">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>