<?php
// PHP code can be added here
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blogs - Vogue Tourism</title>
    <meta name="description" content="Read travel blogs and guides from Vogue Tourism. Get insights, tips, and inspiration for your next adventure.">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <div class="header-top-bar">
            <div class="container d-flex justify-content-between align-items-center">
                <div><i class="bi bi-clock"></i> Mon - Sat: 10am - 7pm</div>
                <div class="headercontact text-white"><a href="tel:+919899928979" class="text-white"><i class="bi bi-telephone"></i> +91-98999-28979</a></div>
            </div>
        </div>
        <nav class="navbar navbar-expand-lg main-header sticky-top">
            <div class="container">
                <a class="navbar-brand" href="index.php"><img src="https://i.imgur.com/7v5gV4j.png" alt="Vogue Tourism Logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">International</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Bali</a></li>
                                <li><a class="dropdown-item" href="#">Dubai</a></li>
                                <li><a class="dropdown-item" href="#">Thailand</a></li>
                                <li><a class="dropdown-item" href="#">Europe</a></li>
                                <li><a class="dropdown-item" href="#">Vietnam</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Domestic</a>
                             <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Andaman</a></li>
                                <li><a class="dropdown-item" href="#">Ladakh</a></li>
                                <li><a class="dropdown-item" href="#">Kerala</a></li>
                                <li><a class="dropdown-item" href="#">Kashmir</a></li>
                            </ul>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="flight.php">Flights</a>                             
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="visa-info.php">Visa Info</a>                             
                        </li>
                        <li class="nav-item"><a class="nav-link" href="aboutus.php">About Us</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main>
     
        <section class="hero-slider-section p-0">
            <div class="h-100 w-100 position-relative">
                <img src="images/banner1.jpg" alt="Blogs" class="w-100 h-100 object-fit-cover"/>
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style="background-color: rgba(0,0,0,0.5);">
                    <div class="text-center text-white">
                        <h1 class="display-4 fw-bold">Our Travel Blogs</h1>
                        <p class="lead">Discover travel tips, guides, and inspiration</p>
                    </div>
                </div>
            </div>   
        </section>

        <section class="section">
            <div class="container">
                <h2 class="section-title">Latest Travel Stories</h2>
                <div class="row g-4">
                    <div class="col-md-6 col-lg-4 d-flex align-items-stretch">
                        <div class="blog-card">
                            <img src="https://www.traveljunky.in/blog_images/NzQ=/NzQ=-main.webp" class="card-img-top" alt="Blog">
                            <div class="card-body">
                                <h5 class="card-title">Top 3 Bali Honeymoon Tours</h5>
                                <p>Discover the most romantic spots and experiences for newlyweds in beautiful Bali.</p>
                                <a href="#" class="blog-link">Read More <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 d-flex align-items-stretch">
                        <div class="blog-card">
                            <img src="https://www.traveljunky.in/blog_images/NzM=/NzM=-main.webp" class="card-img-top" alt="Blog">
                            <div class="card-body">
                                <h5 class="card-title">A Guide to the Top 10 Places in Ladakh</h5>
                                <p>Explore the breathtaking landscapes and cultural treasures of this Himalayan region.</p>
                                <a href="#" class="blog-link">Read More <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 d-flex align-items-stretch">
                        <div class="blog-card">
                            <img src="https://www.traveljunky.in/blog_images/NzI=/NzI=-main.webp" class="card-img-top" alt="Blog">
                            <div class="card-body">
                                <h5 class="card-title">Best Beaches for Water Sports in Bali</h5>
                                <p>Find the perfect spots for surfing, snorkeling, and other exciting water activities.</p>
                                <a href="#" class="blog-link">Read More <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 d-flex align-items-stretch">
                        <div class="blog-card">
                            <img src="https://www.traveljunky.in/blog_images/Njc=/Njc=-main.webp" class="card-img-top" alt="Blog">
                            <div class="card-body">
                                <h5 class="card-title">Discovering Bali's Best Street Food</h5>
                                <p>A culinary journey through the vibrant and flavorful street food scene of Bali.</p>
                                <a href="#" class="blog-link">Read More <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 d-flex align-items-stretch">
                        <div class="blog-card">
                            <img src="images/thailand.jpg" class="card-img-top" alt="Blog">
                            <div class="card-body">
                                <h5 class="card-title">Thailand: Beyond the Beaches</h5>
                                <p>Explore the cultural richness and natural wonders beyond Thailand's famous coastlines.</p>
                                <a href="#" class="blog-link">Read More <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 d-flex align-items-stretch">
                        <div class="blog-card">
                            <img src="images/Dubai-1.jpg" class="card-img-top" alt="Blog">
                            <div class="card-body">
                                <h5 class="card-title">Dubai: A City of Superlatives</h5>
                                <p>Discover the tallest, largest, and most luxurious attractions in this desert metropolis.</p>
                                <a href="#" class="blog-link">Read More <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>

    <section class="section contact-form-section bg-light">
        <div class="container">

            <!-- "Before" Element: Decorative Icons -->
            <div class="intro-icons-wrapper">
                <i class="bi bi-airplane-fill"></i>
                <i class="bi bi-sunrise-fill"></i>
                <i class="bi bi-geo-alt-fill"></i>
            </div>
            
            <h2 class="section-title">Let's Plan Your Perfect Holiday</h2>
            <p class="text-center section-subtitle-text">
                Our experts would love to create a package just for you! Simply fill out the form below and we'll be in touch.
            </p>
            
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="form-wrapper-card">
                        <form action="#" method="POST" class="row g-4">
                            <!-- Name Field -->
                            <div class="col-md-6 form-group">
                                <input type="text" id="name" name="name" class="form-control" placeholder=" " required>
                                <label for="name" class="form-label"><i class="bi bi-person"></i> Enter Your Name*</label>
                            </div>
                            <!-- Destination Field -->
                            <div class="col-md-6 form-group">
                                <input type="text" id="destination" name="destination" class="form-control" placeholder=" " required>
                                <label for="destination" class="form-label"><i class="bi bi-pin-map"></i> Destination*</label>
                            </div>
                            <!-- Contact Number Field -->
                            <div class="col-md-6 form-group">
                                <input type="tel" id="contact" name="contact" class="form-control" placeholder=" " required>
                                <label for="contact" class="form-label"><i class="bi bi-telephone"></i> Contact Number*</label>
                            </div>
                            <!-- Date Field -->
                            <div class="col-md-6 form-group">
                                <!-- JS is used to change input type for better placeholder and date picker functionality -->
                                <input type="text" onfocus="(this.type='date')" onblur="if(!this.value)this.type='text'" id="date" name="date" class="form-control" placeholder=" " required>
                                <label for="date" class="form-label"><i class="bi bi-calendar-event"></i> dd.mm.yyyy</label>
                            </div>
                            <!-- Email Field -->
                            <div class="col-12 form-group">
                                <input type="email" id="email" name="email" class="form-control" placeholder=" ">
                                <label for="email" class="form-label"><i class="bi bi-envelope"></i> Email Address</label>
                            </div>
                            <!-- Submit Button -->
                            <div class="col-12 text-center mt-3">
                                <button type="submit" class="btn cta-button">Submit Request <i class="bi bi-send"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- "After" Element: Social Proof -->
            <div class="outro-proof">
                <span><i class="bi bi-patch-check-fill"></i> Trusted by 10,000+ Happy Travellers</span>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="row gy-4">
                <!-- About Section -->
                <div class="col-lg-3 col-md-6">
                    <img src="https://i.imgur.com/7v5gV4j.png" alt="Vogue Tourism" style="height:40px; margin-bottom: 20px;">
                    <p>Crafting unforgettable travel experiences tailored just for you. Explore the world with confidence.</p>
                </div>

                <!-- Quick Links Section -->
                <div class="col-lg-2 col-md-6">
                    <h5>Quick Links</h5>
                    <a href="flight.php">Flights</a>
                    <a href="visa-info.php">Visa Info</a>
                    <a href="aboutus.php">About Us</a>
                    <a href="blogs.php">Blogs</a> 
                    <a href="career.php">Career</a> 
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                </div>

                <!-- Destinations Section -->
                <div class="col-lg-2 col-md-6">
                    <h5>Destinations</h5>
                    <a href="#">International</a>
                    <a href="#">Domestic</a>                    
                </div>

                <!-- Contact Us Section -->
                <div class="col-lg-3 col-md-6">
                    <h5>Contact Us</h5>
                    <p class="mb-2"><a href="tel:+919509616188"><i class="bi bi-telephone-fill me-2"></i>+91 9509616188</a></p>
                    <p class="mb-3"><a href="mailto:info@voguetourism.com"><i class="bi bi-envelope-fill me-2"></i>info@voguetourism.com</a></p>
                    <p class="mb-2"><strong>Ahmedabad:</strong> 806, Block-A, Solitaire Park, SG Hwy, 380060</p>
                    <p><strong>Ajmer:</strong> Sewa Square, C41B, opp. Nirala Hills, Kotra, 305001</p>
                </div>
                
                <!-- Connect With Us Section -->
                <div class="col-lg-2 col-md-6">
                    <h5>Connect With Us</h5>
                    <p>Let's plan your next adventure!</p>
                    <div class="social-icons">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-youtube"></i></a>
                    </div>
                </div>
            </div>

            <!-- Sub-footer -->
            <div class="sub-footer text-center">
                <p class="mb-0">© 2024 Vogue Tourism. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap, jQuery & Swiper JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="js/custom.js"></script>

</body>
</html>