# Vogue Tourism - Tour Management System

## Overview
This is a comprehensive tour management system for Vogue Tourism, allowing administrators to manage destinations, tours, and customer inquiries. The system includes both an admin panel and a user-facing interface for browsing and inquiring about tours.

## Features

### Admin Panel
- **Authentication**: Secure login system for administrators
- **Dashboard**: Overview of system statistics (tours, destinations, inquiries)
- **Destination Management**: Add, edit, and delete tour destinations
- **Tour Management**: Create, edit, and delete tour packages with details like pricing, duration, and images
- **Inquiry Management**: View and respond to customer inquiries

### User Interface
- **Tour Listings**: Browse domestic, international, and cruise tours
- **Filtering**: Filter tours by duration and destination
- **Tour Details**: View comprehensive information about each tour
- **Inquiry System**: Submit inquiries about specific tours

## Technical Details

### Directory Structure
- `/admin`: Admin panel files
  - `/admin/includes`: Reusable components for the admin panel
- `/css`: Stylesheets including admin.css and style.css
- `/js`: JavaScript files for frontend functionality
- `/our-tours`: Tour listing and details pages
- `/uploads/tours`: Storage for tour images

### Database Structure
- **admins**: Administrator accounts
- **categories**: Tour categories (Adventure, Family, etc.)
- **destinations**: Tour destinations with name and type
- **tours**: Tour packages with details and foreign keys to categories and destinations
- **inquiries**: Customer inquiries about tours

## Installation

1. Place the files in your web server directory
2. Import the database structure using setup_database.php
3. Access the admin panel at `/admin/login.php` with default credentials:
   - Username: admin@voguetourism.com
   - Password: admin123

## Usage

### Admin Tasks
1. Log in to the admin panel
2. Add destinations under the Destinations menu
3. Create tours under the Tours menu
4. View and manage customer inquiries

### User Experience
1. Browse tours by category (domestic, international, cruise)
2. Filter tours by duration or destination
3. View detailed information about a specific tour
4. Submit an inquiry about a tour of interest

## Technologies Used
- PHP for server-side processing
- MySQL for database management
- Bootstrap for responsive design
- JavaScript for interactive elements
- AJAX for form submissions

## Credits
Developed for Vogue Tourism to enhance their online tour booking and management capabilities.