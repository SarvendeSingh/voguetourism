<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'voguetourism';
?>
